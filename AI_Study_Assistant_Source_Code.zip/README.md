# AI Study Assistant using Generative AI

TN Skill / B.Sc. Computer Science Project

## Run
1. Install Python 3.10+.
2. Open a terminal in this folder.
3. Run: `pip install -r requirements.txt`
4. Optional real AI: set `GEMINI_API_KEY` in your environment.
5. Run: `python app.py`
6. Open the local address shown by Flask (normally http://127.0.0.1:5000).

Without an API key, the application runs in demo mode so the interface can still be demonstrated.

## Main modules
- User prompt input
- Explain mode
- Summarization mode
- Quiz generation mode
- Exam-question generation mode
- Generative AI API integration
- Response display
