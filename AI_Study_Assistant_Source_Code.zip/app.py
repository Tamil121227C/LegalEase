"""
AI Study Assistant - TN Skill / B.Sc. Computer Science Project
A simple Flask web application with an optional Google Gemini API backend.
If GEMINI_API_KEY is not set, the app uses a local demo response generator.
"""

import os
from flask import Flask, request, jsonify, render_template_string

app = Flask(__name__)

HTML = """
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>AI Study Assistant</title>
<style>
body{font-family:Arial,sans-serif;background:#f3f6fb;margin:0;color:#172033}
.container{max-width:900px;margin:40px auto;background:white;padding:28px;border-radius:18px;box-shadow:0 8px 30px #0001}
h1{margin-top:0}.sub{color:#596579}
textarea{width:100%;min-height:130px;padding:14px;border:1px solid #ccd4e0;border-radius:10px;font-size:16px;box-sizing:border-box}
select,button{padding:11px 14px;border-radius:9px;border:1px solid #ccd4e0;margin-top:10px}
button{background:#2638c4;color:white;border:0;cursor:pointer}
#answer{white-space:pre-wrap;background:#f7f9fc;padding:18px;border-radius:12px;margin-top:20px;min-height:80px}
</style>
</head>
<body>
<div class="container">
<h1>🤖 AI Study Assistant</h1>
<p class="sub">TN Skill – Generative AI Mini Project | B.Sc. Computer Science</p>
<textarea id="prompt" placeholder="Ask a study question..."></textarea><br>
<select id="mode">
<option value="answer">Explain</option>
<option value="summary">Summarize</option>
<option value="quiz">Generate Quiz</option>
<option value="exam">Generate Exam Questions</option>
</select>
<button onclick="askAI()">Generate</button>
<div id="answer">Your generated response will appear here.</div>
</div>
<script>
async function askAI(){
 const p=document.getElementById('prompt').value;
 const mode=document.getElementById('mode').value;
 document.getElementById('answer').textContent="Generating...";
 const r=await fetch('/generate',{method:'POST',headers:{'Content-Type':'application/json'},
 body:JSON.stringify({prompt:p,mode:mode})});
 const d=await r.json();
 document.getElementById('answer').textContent=d.answer || d.error;
}
</script>
</body>
</html>
"""

def demo_generate(prompt, mode):
    if not prompt.strip():
        return "Please enter a study topic or question."
    if mode == "summary":
        return ("Summary request received for: " + prompt +
                "\n\nA real Generative AI model would identify the important concepts, "
                "remove repetition, and produce a shorter explanation.")
    if mode == "quiz":
        return ("Quiz generated for: " + prompt +
                "\n\n1. Define the main concept.\n2. Explain its working.\n3. Give one real-world application.\n4. State two advantages.\n5. Mention one limitation.")
    if mode == "exam":
        return ("Exam questions for: " + prompt +
                "\n\n1. Define and explain the topic.\n2. Describe the architecture/working process.\n3. Compare two related concepts.\n4. Explain applications and limitations.\n5. Write a short note with an example.")
    return ("AI Study Assistant demo response for: " + prompt +
            "\n\nIn the full Generative AI version, the prompt is tokenized, processed "
            "by a transformer model, and the model predicts the next tokens repeatedly "
            "until a complete answer is produced.")

@app.route("/")
def home():
    return render_template_string(HTML)

@app.route("/generate", methods=["POST"])
def generate():
    data = request.get_json(force=True)
    prompt = data.get("prompt","")
    mode = data.get("mode","answer")

    # Optional Gemini integration. Install google-genai and set GEMINI_API_KEY.
    api_key = os.getenv("GEMINI_API_KEY")
    if api_key:
        try:
            from google import genai
            client = genai.Client(api_key=api_key)
            instruction = {
                "answer":"Explain the topic clearly for a B.Sc. Computer Science student.",
                "summary":"Summarize the topic in simple study notes.",
                "quiz":"Create 5 useful quiz questions with answers.",
                "exam":"Create 5 university-style exam questions and brief answer points."
            }.get(mode, "Explain the topic.")
            response = client.models.generate_content(
                model="gemini-2.0-flash",
                contents=instruction + "\nTopic/question: " + prompt
            )
            return jsonify({"answer": response.text})
        except Exception as e:
            return jsonify({"answer": "AI API error; using demo mode.\n\n" + demo_generate(prompt, mode)})

    return jsonify({"answer": demo_generate(prompt, mode)})

if __name__ == "__main__":
    app.run(debug=True)
